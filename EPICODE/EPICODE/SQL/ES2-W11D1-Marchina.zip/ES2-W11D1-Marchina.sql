
-- SELECT TRACCIE CON GENERE ROCK E POP------------------------------------------------------------------------------------------------------------------------
/*select track.Name, genre.Name
from track
join genre on track.GenreId = genre.GenreId
where genre.name in ('Pop' , 'Rock')
*/

-- SELECT ARTISTI CON LA A ---------------------------------------------------------------------------------------------------------------------------------------
/*SELECT artist.Name, album.Title
from artist 
join album on artist.ArtistId = album.ArtistId
where artist.Name like 'A%'  OR album.Title like 'A%'
*/

-- SELECT TITOLO CON  --------------------------------------------------------------------------------------------------------------------------------------
/*select *
from album 
where anno_publi < 2000 
*/

-- SELECT TRACCE CON GENRE JAZZ E DURATA SOTTO UN TOT------------------------------------------------------------------------------------------------------
/*select *
from track
join genre on track.GenreId = genre.GenreId
where genre.Name = 'Jazz'
or track.Milliseconds < '180000'
*/ 

-- SELECT CON SUBQUERY PER ESTRAPOLARE TRACCE SOTTO LA MEDIA -----------------------------------------------------------------------------------------------
/*select Name, Milliseconds
from track
where Milliseconds > (select avg(Milliseconds) from track)
*/

-- ESERCIZIO 6 CORRETTO ------------------------------------------------------------------------------------------------------------------------------------
/*SELECT distinct GENRE.NAME
FROM TRACK
LEFT JOIN GENRE ON TRACK.GENREID=GENRE.GENREID
WHERE MILLISECONDS>240000;
*/

-- ESERCIZIO 6 CONTORTO E SBAGLIATO ----------------------------------------------------------------------------------------------------------------------------
/*SELECT distinct genre.name
from genre
join track on genre.GenreId = track.GenreId
where Milliseconds < (select avg(Milliseconds) from track)  
*/


/*select artist.Name
from artist
WHERE artist.ArtistId in(
select album.ArtistId
from album
group by album.ArtistId
having count(album.AlbumId)> 1
)
*/

-- select di salvatore più corretta -------------------------------------------------------------------------------------------------------------------------
/*select artist.ArtistId, artist.Name, count(album.Title) as num_album
from artist
left join album on album.ArtistId = artist.ArtistId
group by artist.ArtistId, artist.Name
having num_album >1
order by num_album desc; 
*/

-- esercizio 8 -----------------------------------------------------------------------------------------------------------------------------------------------
/*select Title, avg(Milliseconds) as avg_track
from track
left join album on track.AlbumId = album.AlbumId
group by Title
*/

/*SELECT TITLE, COUNT(DISTINCT NAME) NUM_TRACK
FROM TRACK
LEFT JOIN ALBUM ON TRACK.ALBUMID=ALBUM.ALBUMID
GROUP BY TITLE
HAVING NUM_TRACK>20
ORDER BY TITLE;
*/

/*SELECT TITLE, NAME, MILLISECONDS

FROM (SELECT TITLE, T.NAME, MILLISECONDS, ROW_NUMBER() OVER( PARTITION BY TITLE ORDER BY  T.MILLISECONDS DESC) AS RN
-- T.*, A.TITLE, ROW_NUMBER() OVER( PARTITION BY T.ALBUMID ORDER BY  T.MILLISECONDS DESC) AS RN
FROM TRACK AS T
JOIN ALBUM AS A ON T.ALBUMID=A.ALBUMID) B
WHERE RN=1;
*/
	
