-- select * from album
-- select * from artist
-- select * from customer
-- select * from employee
-- select * from genre
-- select * from invoice
-- select * from invoiceline
-- select * from mediatype
-- select * from playlist
-- select * from playlisttrack
-- select * from track

-- SELECT PRIME 10 RIGHE ALBUM------------------------------------------------------------------------------------------------------------------------------------ 
/*select * from album
limit 10
*/

-- SELECT CONTEGGIO CANZONI TABELLA TRACK------------------------------------------------------------------------------------------------------------------------
-- select count(DISTINCT Name) from track

-- SELECT DEI GENERI NELLA TABELLA GENRE-------------------------------------------------------------------------------------------------------------------------
-- select distinct genre.Name from genre


-- SELECT TUTTE LE TRACCE + GENERE ----------------------------------------------------------------------------------------------------------------------------- 
/*select track.TrackId, track.name, genre.Name
from track 
join genre on track.GenreId = genre.GenreId
*/

-- SELECT ARTISTI CON ALMENO UN ALBUM --------------------------------------------------------------------------------------------------------------------------
/*SELECT distinct artist.name
from artist
join album on artist.ArtistId = album.ArtistId
where title != 'null'
*/

-- SELECT TRACCE CON GENERE ASSOCIATO E TIPO MEDIA -------------------------------------------------------------------------------------------------------------
/*select track.name, genre.name , mediatype.Name 
from track
join mediatype on track.MediaTypeId = mediatype.MediaTypeId
join genre on track.GenreId = genre.GenreId
*/

-- SELECT ARTISTI E ALBUM CORRISPONDENTE------------------------------------------------------------------------------------------------------------------------
/*SELECT artist.name , album.Title
from artist
join album on artist.ArtistId = album.ArtistId
*/

/*select TABLE_NAME
from INFORMATION_SCHEMA.tables
where TABLE_SCHEMA ='chinook';
*/

-- SELECT TRACK CON ARTISTA E ALBUM CORRISPONDENTE--------------------------------------------------------------------------------------------------------------
/*select track.Name, artist.Name, album.Title
from track
join album on track.AlbumId = album.AlbumId
join artist on album.ArtistId = artist.ArtistId 
*/

/*SELECT * 
FROM TRACK
JOIN ALBUM ON TRACK.ALBUMID = ALBUM.ALBUMID
ORDER BY album.AlbumId
*/