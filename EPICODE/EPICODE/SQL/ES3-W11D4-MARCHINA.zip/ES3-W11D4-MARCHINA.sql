
-- Elencate il numero di tracce per ogni genere in ordine discendente, escludendo quei generi che hanno meno di 10 tracce----------------------------------------
/*select count(TrackId) as c_track, GenreId
from track 
group by GenreId
having c_track > 10 
*/

-- Trovate le tre canzoni più costose---------------------------------------------------------------------------------------------------------------------------
/*select Name, UnitPrice
from track
order by UnitPrice
limit 3
*/

-- Elencate gli artisti che hanno canzoni più lunghe di 6 minuti------------------------------------------------------------------------------------------------
/*select artist.Name, track.Milliseconds
from artist 
join album on artist.ArtistId = album.ArtistId
join track on album.AlbumId = track.AlbumId
where track.Milliseconds > 360000
*/

-- Individuate la durata media delle tracce per ogni genere----------------------------------------------------------------------------------------------------
/*select avg(Milliseconds) as m_track, GenreId
from track 
group by GenreId 
*/

-- Elencate tutte le canzoni con la parola “Love” nel titolo, ordinandole alfabeticamente prima per genere e poi per nome-------------------------------------
/*select Name, GenreId
from track 
where Name like '%Love%'
order by GenreId asc, Name asc
*/

-- trovate il costo medio per ogni tipologia------------------------------------------------------------------------------------------------------------------
/*select track.MediaTypeId,mediatype.Name, avg(UnitPrice)
from track 
join mediatype on track.MediaTypeId = mediatype.MediaTypeId
group by track.MediaTypeId
*/

-- Individuate il genere con più tracce------------------------------------------------------------------------------------------------------------------------
/*select genre.genreId, genre.Name , SUM(track.trackId) as top_genre
from genre
join track on genre.GenreId = track.GenreId
group by GenreId
limit 1
*/



-- Trovate gli artisti che hanno lo stesso numero di album dei Rolling Stones-----------------------------------------------------------------------------------
/*select album.artistId, artist.Name, count(album.AlbumId) as c_album
from album
join artist on album.ArtistId = artist.ArtistId
group by ArtistId
HAVING c_album = '3'
*/

-- Trovate l’artista con l’album più costoso
/*select artist.ArtistId, artist.Name as nome_artista , album.Title as titolo_album , sum(track.UnitPrice) as prz_album
from album 
join track on album.AlbumId = track.AlbumId
join artist on album.ArtistId = artist.ArtistId
group by album.AlbumId
order by prz_album desc
*/














