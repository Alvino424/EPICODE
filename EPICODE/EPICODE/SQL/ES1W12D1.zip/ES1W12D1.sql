-- esplorazione preliminare ----------------------------------------------------------------------------------------------------------------------------
-- select * from actor
-- select * from address
-- select * from category
-- select * from city 
-- select * from country
-- select * from customer
-- select * from film 
-- select * from film_actor
-- select * from film_category
-- select * from fil_text
-- select * from inventory
-- select * from language
-- select * from payment
-- select * from rental
-- select * from staff
-- select * from store 

-- Scoprite quanti clienti si sono registrati nel 2006.--------------------------------------------------------------------------------------------
/*select customer_id , first_name , last_name
from customer
where year(create_date) = '2006'
*/

-- Trovate il numero totale di noleggi effettuati il giorno 1/1/2006--------------------------------------------------------------------------------
/*select count(rental_id)
from rental
where date(rental_date) = '2006/1/1'
*/


-- Elencate tutti i film noleggiati nell’ultima settimana e tutte le informazioni legate al cliente che li ha noleggiati.-------------------------
/*SELECT *
FROM 
    rental
left join 
    customer ON customer.customer_id = rental.customer_id
WHERE 
    rental.rental_date BETWEEN  DATE('2006-02-14') AND DATE('2006-02-08');
    */
    
    -- 6
    