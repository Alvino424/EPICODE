-- creo lo schema
-- create schema epicode_es2 ;

-- TABELLA PRODOTTI-------------------------------------------------------------------------------------------------------------------------------------------- 
/*create table prodotto 
(
id_prodotto integer primary key not null,
nome varchar(100),
prezzo double
);
*/

-- TABELLA CLIENTI--------------------------------------------------------------------------------------------------------------------------------------------
/*create table cliente
(
id_cliente integer primary key not null,
nome varchar(50),
email varchar(100)
);
*/

-- TABELLA ORDINI--------------------------------------------------------------------------------------------------------------------------------------------
-- RICHIAMO CHIAMI ESTERNE DA TAB PRODOTTI E CLIENTI 
/*create table ordine
(
id_ordine integer primary key not null,
id_prodotto integer,
id_cliente integer,
quantità double,
foreign key(id_prodotto) references prodotto(id_prodotto),
foreign key(id_cliente) references cliente(id_cliente)
);
*/

-- TABELLA DETTAGLIO ORDINI --------------------------------------------------------------------------------------------------------------------------------
-- creata gia con i due Bonus aggiuntivi, non prende però il dato 'quantità' nel AS 
/*create table dettaglio_ordini
(
id_ordine integer,
id_prodotto integer,
id_cliente integer,
prezzo_tot decimal(10,2) as(quantità * prezzo ),
primary key (id_ordine, id_prodotto, id_cliente),
foreign key(id_ordine) references ordine(id_ordine),
foreign key(id_cliente) references cliente(id_cliente),
foreign key(id_prodotto) references prodotto(id_prodotto)
);
*/

-- INSERT TABELLA PRODTTI-----------------------------------------------------------------------------------------------------------------------------------
/*insert into prodotto(id_prodotto, nome, prezzo) values
(1,'tablet','300.00'),
(2,'mouse','20.00'),
(3,'tastiera','25.00'),
(4,'monitor','180.00'),
(5,'hhd','90.00'),
(6,'ssd','200.00'),
(7,'ram','100.00'),
(8,'router','80.00'),
(9,'webcam','45.00'),
(10,'gpu','1250.00'),
(11,'trackpad','500.00'),
(12,'techmagazine','5.00'),
(13,'martech','50.00');
*/


-- INSERT TABELLA ORDINI ------------------------------------------------------------------------------------------------------------------------------------
/*insert into ordine(id_ordine, id_prodotto, quantità) values
(1,2,'10'),
(2,6,'2'),
(3,5,'3'),
(4,1,'1'),
(5,9,'1'),
(6,4,'2'),
(7,11,'6'),
(8,10,'2'),
(9,3,'3'),
(10,3,'1'),
(11,2,'1');
*/

-- INSERT TABELLA CLIENTE------------------------------------------------------------------------------------------------------------------------------------
/*insert into cliente(id_cliente, nome, email) values
(1,'Antonio', null),
(2,'Battista', 'battista@mailmail.it'),
(3,'Maria','maria@posta.it'),
(4,'Franca', 'franca@lettere.it'),
(5,'Ettore',null),
(6,'Arianna','arianna@posta.it'),
(7,'Piero','piero@lavoro.it');
*/
