-- SELECT PRODOTTI > 50 PLEURI--------------------------------------------------------------------------------------------------------------------------------
-- select prodotto.nome, prodotto.prezzo from prodotto where prezzo > '50'

-- select * from cliente

-- SELECT NOME CON LA A --------------------------------------------------------------------------------------------------------------------------------------
-- SELECT cliente.email, cliente.nome from cliente where nome like 'A%'

-- SELECT ORDINI CON QUANTITA MAGGIORE 10 O PREZZO INF 100 ----------------------------------------------------------------------------------------------------
/*SELECT *
FROM ORDINE
JOIN PRODOTTO ON ordine.id_prodotto = prodotto.id_prodotto
WHERE ordine.quantità > 10 
or prodotto.prezzo < 100
*/

-- SELECT DEL PREZZO CON NOME CONTENENTE PAROLA-----------------------------------------------------------------------------------------------------------------
-- select prezzo from prodotto where nome like '%tech%'

-- select di campi vuoti email nei clienti----------------------------------------------------------------------------------------------------------------------
-- SELECT * FROM cliente WHERE email is null

-- select prodotti iniz M final E -----------------------------------------------------------------------------------------------------------------------------
-- select * from prodotto where nome like 'M%e'