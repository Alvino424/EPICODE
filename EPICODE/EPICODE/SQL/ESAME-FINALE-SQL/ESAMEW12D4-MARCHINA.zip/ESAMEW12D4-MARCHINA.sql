-- CREATE SCHEMA TOYSGROUP
/*CREATE TABLE product(
id_prod integer primary key auto_increment,
nome varchar (70),
prezzo double,
categoria varchar(70),
età varchar (10),
data_inserimento date
);
*/

/*create table sales(
id_transazione integer primary key auto_increment,
id_prod integer,
id_regione integer,
quantità double,
importo double,
data_transazione date,
foreign key (id_prod) references product(id_prod),
foreign key(id_regione) references region(id_regione)
)
*/


/*create table region(
id_regione integer primary key auto_increment,
descrizione varchar (50)
)
*/

-- insert dati random per tabella product --------------------------------------------------------------------------------------------------------
/*INSERT INTO product (nome, prezzo, categoria, età, data_inserimento) VALUES 
('Power Pro', 286.52, 'Elettronica', '6-16', '2023-10-03'), 
('Black Max', 495.15, 'Elettronica', '2-12', '2023-05-17'), 
('Civil Elite', 257.26, 'Sport', '8-18', '2023-12-04'), 
('Course Elite', 285.54, 'Abbigliamento', '2-12', '2023-08-18'), 
('Player Max', 447.91, 'Giochi', '2-12', '2023-05-15'), 
('Out Max', 111.63, 'Sport', '6-16', '2023-05-13'), 
('Community Elite', 417.4, 'Elettronica', '2-12', '2023-04-17'), 
('Hit Max', 219.81, 'Giochi', '8-18', '2024-02-16'), 
('Individual Elite', 272.72, 'Libri', '8-18', '2024-02-19'), 
('Treatment Pro', 403.82, 'Libri', '6-16', '2023-05-17');
*/

-- insert dati random per tabella region-------------------------------------------------------------------------------------------------------------- 
/*INSERT INTO region(descrizione) VALUES 
('Abruzzo'), 
('Basilicata'), 
('Calabria'), 
('Campania'), 
('Emilia-Romagna'), 
('Friuli-Venezia Giulia'), 
('Lazio'), 
('Liguria'), 
('Lombardia'), 
('Marche'), 
('Molise'), 
('Piemonte'), 
('Puglia'), 
('Sardegna'), 
('Sicilia'), 
('Toscana')
*/

-- insert dati random per tabella salse-----------------------------------------------------------------------------------------------------------
/*INSERT INTO sales (id_prod, id_regione, quantità, importo, data_transazione) VALUES 
(1, 9, 6, 586.61, '2024-01-03'), 
(2, 5, 9, 82.05, '2023-10-02'), 
(3, 16, 3, 496.3, '2023-09-02'), 
(4, 4, 2, 235.55, '2023-03-19'), 
(5, 13, 2, 432.84, '2023-11-25'), 
(6, 9, 8, 699.95, '2023-05-13'), 
(7, 10, 10, 997.05, '2023-10-17'), 
(8, 13, 1, 387.64, '2023-10-15'), 
(9, 16, 1, 927.02, '2023-11-28'), 
(10, 4, 8, 908.14, '2023-12-30')
*/

-- Verificare che i campi definiti come PK siano univoci. ---------------------------------------------------------------------------------------------
-- select id_prod from product
-- select id_region from region
-- select id_transazione from sales

-- Esporre l’elenco dei soli prodotti venduti e per ognuno di questi il fatturato totale per anno-------------------------------------------------------
/*select sales.id_prod, product.nome , year(sales.data_transazione) as anno, sum(sales.importo) as fatturato 
from sales
join product on sales.id_prod = product.id_prod
group by sales.id_prod,
		 year(sales.data_transazione)
order by sales.id_prod,
		 anno ;
*/         

-- Esporre il fatturato totale per stato(regione) per anno. Ordina il risultato per data e per fatturato decrescente-----------------------------------
/*select  sum(sales.importo) as fatturato, region.id_regione, region.descrizione, year(sales.data_transazione) as anno
from sales
join region on sales.id_regione = region.id_regione
group by region.id_regione,
		year(sales.data_transazione) 
order by anno,
		fatturato desc
*/

-- Rispondere alla seguente domanda: qual è la categoria di articoli maggiormente richiesta dal mercato?
 /*select product.categoria , count(sales.quantità) q_tot
 from  sales
 join product on sales.id_prod = product.id_prod
 group by product.categoria
 order by q_tot desc
 limit 1
 */
 
 
 -- Rispondere alla seguente domanda: quali sono, se ci sono, i prodotti invenduti? Proponi due approcci risolutivi differenti. -----------------------
 -- 1
 /*select product.id_prod
 from product
 left join sales on product.id_prod = sales.id_prod
 where sales.id_prod is null
 */
 
 -- 2
 /*select product.id_prod
 from product
 where not exists(
 select product.id_prod
 from sales
 where sales.id_prod = product.id_prod)
 */
 
 -- Esporre l’elenco dei prodotti con la rispettiva ultima data di vendita (la data di vendita più recente)
 /*select  product.id_prod, product.nome, sales.data_transazione
 from sales
 join product on sales.id_prod = sales.id_prod
 where sales.data_transazione = (select max(data_transazione)from sales)
 */
 
 


 


