-- Identificate tutti i clienti che non hanno effettuato nessun noleggio a gennaio 2006.----------------------------------------------------------------
/*select rental.customer_id, customer.customer_id
from rental 
join customer on rental.customer_id = customer.customer_id AND rental.rental_date BETWEEN '2006-01-01' AND '2006-01-31'
where rental_date is null
*/

-- Elencate tutti i film che sono stati noleggiati più di 10 volte nell’ultimo quarto del 2005---------------------------------------------------------
/*select film.film_id, film.description, count(rental.rental_id) as c_rent 
from film
join inventory on film.film_id = inventory.film_id
join rental on inventory.inventory_id = rental.inventory_id
where rental.rental_date between '2005-08-01' and '2005-12-21'
group by film.film_id
having c_rent > 10
*/

-- Trovate il numero totale di noleggi effettuati il giorno 1/1/2006------------------------------------------------------------------------------------
/*select count(rental_id) 
from rental
where date(rental_date) = '2006-01-01'
*/

-- Calcolate la somma degli incassi generati nei weekend (sabato e domenica)---------------------------------------------------------------------------
/*select sum(amount)
from payment
where dayofweek(payment_date) in (1,7)
*/

-- Individuate il cliente che ha speso di più in noleggi-----------------------------------------------------------------------------------------------
/*select customer_id, sum(amount) as s_amount 
from payment
group by customer_id
order by s_amount desc
limit 1
*/

-- elencate i 5 film con la maggior durata media noleggio----------------------------------------------------------------------------------------------
/*select film.film_id, avg(timestampdiff(day, rental_date, return_date)) as rent_duration
from rental
join inventory on rental.inventory_id = inventory.inventory_id
join film on inventory.film_id = film.film_id
group by film.film_id
order by rent_duration
limit 5
*/

-- Calcolate il tempo medio tra due noleggi consecutivi da parte di un cliente.------------------------------------------------------------------------
/*select customer_id, avg(timestampdiff(day, rental_date, return_date)) as rent_duration
from rental 
group by customer_id
*/

-- Individuate il numero di noleggi per ogni mese del 2005--------------------------------------------------------------------------------------------

