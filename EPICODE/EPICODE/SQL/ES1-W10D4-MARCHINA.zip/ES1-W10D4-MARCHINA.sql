-- MOLTE SELECT NON FUNZIONANO PERCHè L'ESERCIZIO DEVO SISTEMARLO, PERò SONO COMUNQUE GISUTE, SISTEMERò APPENA AVRò TEMPO DA DEDICARCI

--  SELECT LAUREA IN ECONOMIA --------------------------------------------------------------------------------------------------------------------------------
/*select * 
from impiegato
where titolo = 'Laurea in Economia'
*/

-- SELECT impiegati che lavorano come cassiere o diploma in informatica----------------------------------------------------------------------------------------
/*SELECT *
FROM impiegato
JOIN servizio_impiegato ON impiegati.Cod_Fisc = servizio_impiegato.Cod_Fisc
WHERE servizio_impiegato.carica = 'Cassiere'
OR impiegato.titolo = 'Diploma in Informatica';
*/

-- SELECT NOME E TITOLO CON INIZIO DOPO DATA-------------------------------------------------------------------------------------------------------------------
/*SELECT impiegato.nome, impiegato.titolo
FROM impiegato
JOIN servizio_impiegato on impiegato.Cod_Fisc = servizio_impiegato.Cod_Fisc
WHERE servizio_impiegato.data_inizio > '2023-01-01' ;
*/

-- SELECT UNIVOCA DEI TITOLI DI STUDIO--------------------------------------------------------------------------------------------------------------------------
-- SELECT distinct impiegato.titolo FROM impiegato 


-- SELECT DEGLI IMPIEGATI CHE NON HANNO UNA LAUREA IN ECONOMIA--------------------------------------------------------------------------------------------------
-- SELECT * FROM impiegato WHERE titolo != 'Laurea in Economia'


-- SELECT IMPIEGATI CON DATA INIZIO PRIMA DI UNA DATA E TITOLO UGUALE A COMMESSO--------------------------------------------------------------------------------
/*SELECT impiegato.Cod_Fisc 
from impiegato 
join servizio_impiegato on impiegato.Cod_Fisc = servizio_impiegato.Cod_Fisc
WHERE servizio_impiegato.data_inizio < '2023-07-01'
AND impiegato.titolo = 'Commesso'
*/

-- SELECT TITOLO E SVILUPPATORE VIDEOGIOCO CON ANNO 2020--------------------------------------------------------------------------------------------------------
/*select videogioco.titolo, videogioco.sviluppatore
FROM videogioco
WHERE anno = '2020'
*/



