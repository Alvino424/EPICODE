
/* TABELLA STORE---------------------------------------------------------------------------------------------------------------------------------------------
create table Store 
(
id_store integer not null,
indirizzo varchar(50),
telefono varchar(10)
);
*/

 -- TABELLA IMPIEGATO------------------------------------------------------------------------------------------------------------------------------------------
 -- drop table Impiegato ;
/*create table Impiegato 
(
Cod_Fisc varchar(16) not null,
nome varchar(50) not null,
titolo varchar(30),
mail varchar(50),
unique(Cod_Fisc),
primary key(nome)
);
*/


/* TABELLA SERVIZIO_IMPIEGATO--------------------------------------------------------------------------------------------------------------------------------
create table servizio_impiegato 
(
c_fiscale varchar(16) not null,
id_store integer not null,
data_inizio date,
data_fine date,
carica varchar(50),
unique(c_fiscale, id_store, data_inizio)
);
*/

/* TABELLA VIDEOGIOCO--------------------------------------------------------------------------------------------------------------------------------------- 
create table videogioco 
(
titolo varchar(50),
sviluppatore varchar(50),
anno year ,
costo float ,
genere varchar (20),
remake varchar(50)
);
*/
-- TABELLA COLLOCAZIONE VIDEOGIOCO
/*create table collocazione_videogioco
(
id_collo integer primary key not null auto_increment ,
id_store integer,
titolo varchar(100),
constraint id_store foreign key (id_store)
	references store(id_store),
constraint titolo foreign key(titolo)
	references videogioco(titolo)	
)

/* INSERT TABELLA STORE -------------------------------------------------------------------------------------------------------------------------------------
insert into store(id_store, indirizzo, telefono ) values
(1,'Via Roma 123, Milano', '+39031234567'),
(2, 'Corso Italia 456,Roma', '+39067654321'),
(3, 'Piazza San Marco 789, Roma', '+39041987456'),
(4,'Viale degli ulivi 234, Napoli', '+390813456789'),
(5,'Via Torino 567, Torino','+390118765432'),
(6,'Corso Vittorio Emanuele 123, Firenze','+39055234567'),
(7,'Piazza del duomo 213,Bologna', '+390518765432'),
(8,'Via Garibaldi 456, Genova', '+390102345678')
*/

 /* INSERT DATI IMPIEGATO -------------------------------------------------------------------------------------------------------------------------------------
INSERT into impiegato(Cod_Fisc, nome, titolo, mail) values
('ABC12345XYZ67890','Mario Rossi','Laurea in Economia',' mario.rossi@email.com'),
('DEF67890XYZ12345','Anna Verdi','Diploma di Ragioneria',' mario.rossi@email.com'),
('GHI12345XYZ67890','Luigi Bianchi',' Laurea in Informatica','luigi.bianchi@email.com'),
('JKL67890XYZ12345','Laura Neri','Laurea in Lingue','laura.neri@email.com'),
('MNO12345XYZ67890','Andrea Moretti','Diploma di Geometra','andrea.moretti@email.com'),
('PQR67890XYZ12345','Giulia Ferrara','Laurea in Psicologia','giulia.ferrara@email.com'),
('STU12345XYZ67890','Marco Esposito','Diploma di Elettronica','marco.esposito@email.com'),
('VWX67890XYZ12345','Sara Romano','Laurea in Giurisprudenza','sara.romano@email.com'),
('YZA12345XYZ67890','Roberto De Luca','Diploma di Informatica','roberto.deluca@email.com'),
('BCD67890XYZ12345','Elena Santoro','Laurea in Lettere','elena.santoro@email.com')
*/

/* INSERT SERVIZIO IMPIEGATO---------------------------------------------------------------------------------------------------------------------------------
insert into servizio_impiegato(c_fiscale, id_store, data_inizio, data_fine, carica) values
('ABC12345XYZ67890',1, '2023-01-01', '2023-12-31', 'Cassiere'),
('DEF67890XYZ12345',2, '2023-02-01', '2023-11-30', 'Commesso'),
('GHI12345XYZ67890',3, '2023-03-01', '2023-10-31', 'Magazziniere'),
('JKL67890XYZ12345',4, '2023-04-01', '2023-09-30', 'Addetto alle vendite'),
('MNO12345XYZ67890',5, '2023-05-01', '2023-08-31', 'Addetto alle pulizie'),
('PQR67890XYZ12345',6, '2023-06-01', '2023-07-31', 'Commesso'),
('STU12345XYZ67890',7, '2023-07-01', '2023-06-30', 'Commesso'),
('VWX67890XYZ12345',8, '2023-08-01', '2023-05-31', 'Cassiere'),
('YZA12345XYZ67890',9, '2023-09-01', '2023-04-30', 'Cassiere'),
('BCD67890XYZ12345',10, '2023-10-01', '2023-03-31', 'Cassiere')
*/

/* INSERT VIEOGIOCHI------------------------------------------------------------------------------------------------------------------------------------------
insert into videogioco(titolo, sviluppatore, anno, costo, genere, remake) values
('Fifa 2023','EA Sports', '2023', '49.99', 'Calcio', null),
('Assassin s Creed: Valhalla','Ubisoft','2020','59.99','Action', null),
('Super Mario Odyssey', 'Nintendo', '2017','39.99','Platform,', null),
('The Last of Us Part II','Naughty Dog', '2020', '69.99','Action',null),
('Cyberpunk 2077', 'CD Projekt Red', '2020', '49.99', 'RPG', null),
('Animal Crossing: New Horizons','Nintendo', '2020', '54.99', 'Simulation', null),
('Call of Duty: Warzone', 'Call of Duty: Warzone','2020', '0.00' , 'FPS', null),
('The Legend of Zelda: Breath of the Wild', 'Nintendo', '2017', '59.99', 'Action-Adventure', null),
('Fortnite', 'Epic Games', '2017', '0.00','Battle Royale', null),
('Red Dead Redemption 2', 'Rockstar Games', '2018','39.99', 'Action-Adventure',null)
*/

-- alter table store MODIFY COLUMN telefono varchar(16) ;

-- SELECT * FROM videogioco
-- SELECT * FROM impiegato
-- SELECT * FROM servizio_impiegato
-- SELECT * FROM store

